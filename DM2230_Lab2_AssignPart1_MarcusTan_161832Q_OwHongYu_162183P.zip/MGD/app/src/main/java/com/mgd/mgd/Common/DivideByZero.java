package com.mgd.mgd.Common;

public class DivideByZero extends Exception
{
    DivideByZero() { super("Divide By Zero"); }
//public final String what() { return "Divide By Zero"; }
}
