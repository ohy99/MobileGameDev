package com.mgd.mgd.Components.Collision;

public class CharacterResponse extends CollisionResponse{
    //attach hp here and reduce hp
}
