package com.mgd.mgd.Components;

/**
 * Created by 162183P on 12/1/2017.
 */

public interface ComponentBase
{
    //Init is to init the variables only
    void Init();
    void Update(double dt);

}

